#include "bsp_spi.h"

/* SPI2 CLK PA12 */
#define SPI_CLK_GPIO_Port GPIOA
#define SPI_CLK_Pin LL_GPIO_PIN_12

/* SPI2 MOSI PB15 */
#define SPI_MOSI_GPIO_Port GPIOB
#define SPI_MOSI_Pin LL_GPIO_PIN_15

/* SPI2 MISO PB14 */
#define SPI_MISO_GPIO_Port GPIOB
#define SPI_MISO_Pin LL_GPIO_PIN_14

/* SPI2 CS0 PA11 */
#define SPI_CS0_GPIO_Port GPIOA
#define SPI_CS0_Pin LL_GPIO_PIN_11

/**
 * @brief 初始化
 *
 */
void BSP_SPI_Init(void)
{
    LL_GPIO_InitTypeDef GPIO_InitStruct = {0};

    LL_AHB4_GRP1_EnableClock(LL_AHB4_GRP1_PERIPH_GPIOA);
    LL_AHB4_GRP1_EnableClock(LL_AHB4_GRP1_PERIPH_GPIOB);
    LL_AHB4_GRP1_EnableClock(LL_AHB4_GRP1_PERIPH_GPIOC);
    LL_AHB4_GRP1_EnableClock(LL_AHB4_GRP1_PERIPH_GPIOD);
    LL_AHB4_GRP1_EnableClock(LL_AHB4_GRP1_PERIPH_GPIOE);
    LL_AHB4_GRP1_EnableClock(LL_AHB4_GRP1_PERIPH_GPIOH);

    /* 拉高所有片选 */
    LL_GPIO_SetOutputPin(SPI_CS0_GPIO_Port, SPI_CS0_Pin);

    LL_GPIO_ResetOutputPin(SPI_CLK_GPIO_Port, SPI_CLK_Pin);

    GPIO_InitStruct.Pin = SPI_CS0_Pin;
    GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
    GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
    GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
    LL_GPIO_Init(SPI_CS0_GPIO_Port, &GPIO_InitStruct);

    /* SPI其他引脚 */
    GPIO_InitStruct.Pin = SPI_CLK_Pin;
    GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
    GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
    GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
    LL_GPIO_Init(SPI_CLK_GPIO_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = SPI_MOSI_Pin;
    GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
    GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
    GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
    LL_GPIO_Init(SPI_MOSI_GPIO_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = SPI_MISO_Pin;
    GPIO_InitStruct.Mode = LL_GPIO_MODE_INPUT;
    GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
    GPIO_InitStruct.Pull = LL_GPIO_PULL_UP;
    LL_GPIO_Init(SPI_MISO_GPIO_Port, &GPIO_InitStruct);
}

/**
 * @brief 取消初始化，所有引脚进入高阻状态
 *
 */
void BSP_SPI_Deinit(void)
{
}

/**
 * @brief 片选
 *
 * @param index     序号
 * @param status    1选中
 */
void BSP_SPI_ChipSelect(uint32_t index, uint8_t status)
{
    switch (index)
    {
    case 0:
        (status > 0) ? LL_GPIO_ResetOutputPin(SPI_CS0_GPIO_Port, SPI_CS0_Pin) : //
            LL_GPIO_SetOutputPin(SPI_CS0_GPIO_Port, SPI_CS0_Pin);
        break;

    default:
        /* 参数错误拉高所有片选 */
        LL_GPIO_SetOutputPin(SPI_CS0_GPIO_Port, SPI_CS0_Pin);
        break;
    }
}

uint8_t BSP_SPI_TransferByte(uint8_t data)
{
    for (uint32_t i = 0; i < 8; i++)
    {
        (data & 0x80) ? LL_GPIO_SetOutputPin(SPI_MOSI_GPIO_Port, SPI_MOSI_Pin) : //
            LL_GPIO_ResetOutputPin(SPI_MOSI_GPIO_Port, SPI_MOSI_Pin);
        LL_GPIO_SetOutputPin(SPI_CLK_GPIO_Port, SPI_CLK_Pin); // 上升沿
        data = data << 1;
        data = data | ((LL_GPIO_ReadInputPort(SPI_MISO_GPIO_Port) & SPI_MISO_Pin) ? 0x01 : 0x00);
        LL_GPIO_ResetOutputPin(SPI_CLK_GPIO_Port, SPI_CLK_Pin); // 下降沿
    }

    return data;
}

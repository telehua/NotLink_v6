#ifndef __BSP_SPI_H__
#define __BSP_SPI_H__

#include "stm32h7xx_ll_bus.h"
#include "stm32h7xx_ll_gpio.h"
#include <stdint.h>

void BSP_SPI_Init(void);
void BSP_SPI_Deinit(void);
void BSP_SPI_ChipSelect(uint32_t index, uint8_t status);
uint8_t BSP_SPI_TransferByte(uint8_t data);

#endif /* __BSP_SPI_H__ */

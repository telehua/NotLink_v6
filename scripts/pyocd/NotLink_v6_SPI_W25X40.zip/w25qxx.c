#include "w25qxx.h"

/**
 * @brief 初始化
 *
 */
void W25QXX_Init(void)
{
    BSP_SPI_Init();
}

/**
 * @brief 取消初始化
 *
 */
void W25QXX_Deinit(void)
{
    BSP_SPI_Deinit();
}

/**
 * @brief 读SR1
 *
 * @return uint8_t
 */
uint8_t W25QXX_ReadSR1(void)
{
    BSP_SPI_ChipSelect(0, 1);
    BSP_SPI_TransferByte(W25QXX_CMD_READ_SR1);
    uint8_t r = BSP_SPI_TransferByte(0xFF);
    BSP_SPI_ChipSelect(0, 0);
    return r;
}

/**
 * @brief 允许写
 *
 */
void W25QXX_WriteEnable(void)
{
    BSP_SPI_ChipSelect(0, 1);
    BSP_SPI_TransferByte(W25QXX_CMD_WRITE_ENABLE);
    BSP_SPI_ChipSelect(0, 0);
}

/**
 * @brief 不允许写
 *
 */
void W25QXX_WriteDisable(void)
{
    BSP_SPI_ChipSelect(0, 1);
    BSP_SPI_TransferByte(W25QXX_CMD_WRITE_DISABLE);
    BSP_SPI_ChipSelect(0, 0);
}

/**
 * @brief 读byte
 *
 * @param flash_addr    地址
 * @return uint8_t      数据
 */
uint8_t W25QXX_ReadByte(uint32_t flash_addr)
{
    BSP_SPI_ChipSelect(0, 1);
    BSP_SPI_TransferByte(W25QXX_CMD_FAST_READ);
    BSP_SPI_TransferByte(flash_addr >> 16);
    BSP_SPI_TransferByte(flash_addr >> 8);
    BSP_SPI_TransferByte(flash_addr);
    BSP_SPI_TransferByte(0xFF); // dummy
    uint8_t r = BSP_SPI_TransferByte(0xFF);
    BSP_SPI_ChipSelect(0, 0);
    return r;
}

/**
 * @brief 写byte
 *
 * @param flash_addr    地址
 * @param data          数据
 */
void W25QXX_WriteByte(uint32_t flash_addr, uint8_t data)
{
    W25QXX_WriteEnable();

    BSP_SPI_ChipSelect(0, 1);
    BSP_SPI_TransferByte(W25QXX_CMD_PAGE_PROGRAM);
    BSP_SPI_TransferByte(flash_addr >> 16);
    BSP_SPI_TransferByte(flash_addr >> 8);
    BSP_SPI_TransferByte(flash_addr);
    BSP_SPI_TransferByte(data);
    BSP_SPI_ChipSelect(0, 0);

    while ((W25QXX_ReadSR1() & 0x01) == 1)
    {
    }

    W25QXX_WriteDisable();
}

/**
 * @brief 块读取
 *
 * @param flash_addr    地址
 * @param data_buff     读出数据的缓冲区
 * @param size          大小(byte)
 */
void W25QXX_ReadMass(uint32_t flash_addr, uint8_t *data_buff, uint32_t size)
{
    BSP_SPI_ChipSelect(0, 1);
    BSP_SPI_TransferByte(W25QXX_CMD_FAST_READ);
    BSP_SPI_TransferByte(flash_addr >> 16);
    BSP_SPI_TransferByte(flash_addr >> 8);
    BSP_SPI_TransferByte(flash_addr);
    BSP_SPI_TransferByte(0xFF); // dummy
    for (uint32_t i = 0; i < size; i++)
    {
        data_buff[i] = BSP_SPI_TransferByte(0xFF);
    }
    BSP_SPI_ChipSelect(0, 0);
}

/**
 * @brief 块写入
 * 
 * @param flash_addr    地址 
 * @param data_buff     数据缓冲区
 * @param size          大小(byte)
 */
void W25QXX_WriteMass(uint32_t flash_addr, uint8_t *data_buff, uint32_t size)
{
    uint32_t op_size;
    W25QXX_WriteEnable();

    while (size)
    {
        // 本次操作的大小
        op_size = W25QXX_PAGE_SIZE - (flash_addr % W25QXX_PAGE_SIZE);

        if (size < op_size)
        {
            op_size = size;
        }

        BSP_SPI_ChipSelect(0, 1);
        BSP_SPI_TransferByte(W25QXX_CMD_PAGE_PROGRAM);
        BSP_SPI_TransferByte(flash_addr >> 16);
        BSP_SPI_TransferByte(flash_addr >> 8);
        BSP_SPI_TransferByte(flash_addr);
        for (uint32_t i = 0; i < op_size; i++)
        {
            BSP_SPI_TransferByte(data_buff[i]); // 无限连续读
        }
        BSP_SPI_ChipSelect(0, 0);

        while ((W25QXX_ReadSR1() & 0x01) == 1)
        {
        }

        size -= op_size;
        flash_addr += op_size;
        data_buff += op_size;
    }

    W25QXX_WriteDisable();
}

/**
 * @brief 扇区擦除
 *
 * @param flash_addr
 */
void W25QXX_EraseSector4K(uint32_t flash_addr)
{
    W25QXX_WriteEnable();

    BSP_SPI_ChipSelect(0, 1);
    BSP_SPI_TransferByte(W25QXX_CMD_SECTOR_ERASE_4K);
    BSP_SPI_TransferByte(flash_addr >> 16);
    BSP_SPI_TransferByte(flash_addr >> 8);
    BSP_SPI_TransferByte(flash_addr);
    BSP_SPI_ChipSelect(0, 0);

    while ((W25QXX_ReadSR1() & 0x01) == 1)
    {
    }

    W25QXX_WriteDisable();
}

/**
 * @brief 扇区擦除
 *
 * @param flash_addr
 */
void W25QXX_EraseSector64K(uint32_t flash_addr)
{
    W25QXX_WriteEnable();

    BSP_SPI_ChipSelect(0, 1);
    BSP_SPI_TransferByte(W25QXX_CMD_BLOCK_ERASE_64K);
    BSP_SPI_TransferByte(flash_addr >> 16);
    BSP_SPI_TransferByte(flash_addr >> 8);
    BSP_SPI_TransferByte(flash_addr);
    BSP_SPI_ChipSelect(0, 0);

    while ((W25QXX_ReadSR1() & 0x01) == 1)
    {
    }

    W25QXX_WriteDisable();
}

/**
 * @brief 读
 *
 * @return uint32_t
 */
uint32_t W25QXX_ReadJedec(void)
{
    uint32_t id = 0;

    BSP_SPI_ChipSelect(0, 1);
    BSP_SPI_TransferByte(W25QXX_CMD_READ_JEDEC_ID);
    id = BSP_SPI_TransferByte(0);
    id = id << 8;
    id |= BSP_SPI_TransferByte(0);
    id = id << 8;
    id |= BSP_SPI_TransferByte(0);
    BSP_SPI_ChipSelect(0, 0);

    return id;
}

/**
 * @brief 全片擦除
 *
 */
void W25QXX_EraseChip(void)
{
    W25QXX_WriteEnable();

    BSP_SPI_ChipSelect(0, 1);
    BSP_SPI_TransferByte(W25QXX_CMD_CHIP_ERASE);
    BSP_SPI_ChipSelect(0, 0);

    while ((W25QXX_ReadSR1() & 0x01) == 1)
    {
    }

    W25QXX_WriteDisable();
}

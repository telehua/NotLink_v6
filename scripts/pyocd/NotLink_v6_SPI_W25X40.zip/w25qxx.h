#ifndef __W25QXX_H__
#define __W25QXX_H__

#include "bsp_spi.h"

#define W25QXX_PAGE_SIZE 256U

#define W25QXX_CMD_WRITE_ENABLE 		0x06 /* 写使能 */
#define W25QXX_CMD_WRITE_DISABLE 		0x04 /*  */
#define W25QXX_CMD_FAST_READ 				0x0B /* 快速读 */
#define W25QXX_CMD_SECTOR_ERASE_4K 	0x20 /* 块擦除 */
#define W25QXX_CMD_BLOCK_ERASE_32K 	0x52 /* 扇区擦除 */
#define W25QXX_CMD_BLOCK_ERASE_64K 	0xD8 /* 扇区擦除 */
#define W25QXX_CMD_CHIP_ERASE 			0xC7 /* 片擦除 */
#define W25QXX_CMD_READ_SR1 				0x05 /* 读SR1 */
#define W25QXX_CMD_PAGE_PROGRAM 		0x02 /* 页编程 */
#define W25QXX_CMD_READ_JEDEC_ID 		0x9F /* 读JEDEC */

void W25QXX_Init(void);
void W25QXX_Deinit(void);
uint8_t W25QXX_ReadSR1(void);
void W25QXX_WriteEnable(void);
void W25QXX_WriteDisable(void);
uint8_t W25QXX_ReadByte(uint32_t flash_addr);
void W25QXX_WriteByte(uint32_t flash_addr, uint8_t data);
void W25QXX_ReadMass(uint32_t flash_addr, uint8_t *data_buff, uint32_t size);
void W25QXX_WriteMass(uint32_t flash_addr, uint8_t *data_buff, uint32_t size);
void W25QXX_EraseSector4K(uint32_t flash_addr);
void W25QXX_EraseSector64K(uint32_t flash_addr);
uint32_t W25QXX_ReadJedec(void);
void W25QXX_EraseChip(void);

#endif /* __W25QXX_H__ */
